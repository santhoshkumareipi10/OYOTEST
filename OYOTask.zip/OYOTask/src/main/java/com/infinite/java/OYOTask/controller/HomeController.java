package com.infinite.java.OYOTask.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.infinite.java.OYOTask.model.Billing;
import com.infinite.java.OYOTask.model.Booking;
import com.infinite.java.OYOTask.model.Room;
import com.infinite.java.OYOTask.DAO.OYODAO;

@Controller
public class HomeController { 
	
	@Autowired
	 private OYODAO OYODAO;

	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/bookingform", method = RequestMethod.GET)
	 public ModelAndView letsbook(ModelAndView model) {
		List<Room> listroomid = OYODAO.list();
		ArrayList<String> list=new ArrayList<String>();
		for (Room room : listroomid) {
			list.add(room.getRoomid());
		}
		model.addObject("listroomid",list);
	     Booking booking = new Booking();
	     model.addObject("booking", booking);
	     model.setViewName("bookingform");
	     return model;
	 }
	
	@RequestMapping(value = "/savebooking", method = RequestMethod.POST)
	 public ModelAndView savebooking(@ModelAttribute Booking booking) {
	     OYODAO.booking(booking);
	     return new ModelAndView("redirect:/");
	 }
	
	@RequestMapping(value = "/addroom", method = RequestMethod.GET)
	 public ModelAndView addroom(ModelAndView model) {
	     Room room = new Room();
	     model.addObject("room", room);
	     model.setViewName("addroom");
	     return model;
	 }
	
	@RequestMapping(value = "/saveroom", method = RequestMethod.POST)
	 public ModelAndView saveroom(@ModelAttribute Room room) {
	     OYODAO.addroom(room);
	     return new ModelAndView("redirect:/");
	 }
	
	@RequestMapping(value="/showroom")
	public ModelAndView listRoom(ModelAndView model) throws IOException{
	     List<Room> listRoom = OYODAO.list();
	     model.addObject("listRoom", listRoom);
	     model.setViewName("showroom");
	     return model;
	 }
	
	@RequestMapping(value="/showbook")
	public ModelAndView listBook(ModelAndView model) throws IOException{
	     List<Booking> listBook = OYODAO.blist();
	     model.addObject("listBook", listBook);
	     model.setViewName("showbook");
	     return model;
	 }
	
	@RequestMapping(value="/showbill")
	public ModelAndView listBill(ModelAndView model) throws IOException{
	     List<Billing> listBill = OYODAO.billist();
	     model.addObject("listBill", listBill);
	     model.setViewName("showbill");
	     return model;
	 }
	
	@RequestMapping(value = "/billingform", method = RequestMethod.GET)
	 public ModelAndView letsbill(ModelAndView model) {
	     Billing billing = new Billing();
	     model.addObject("billing", billing);
	     model.setViewName("billingform");
	     return model;
	 }
	
	@RequestMapping(value = "/savebilling", method = RequestMethod.POST)
	 public ModelAndView savebilling(@ModelAttribute Billing billing) {
		String rid= billing.getRoomid();
		int daysbill =0;
		List<Booking> lb = OYODAO.searchbook(rid);
		for (Booking b : lb) {
		long ms = b.getChkoutdate().getTime() - b.getChkindate().getTime();
	    long m = ms / (1000 * 24 * 60 * 60);
	    int days = (int) m;
	    days = days + 1;
	    daysbill=days;
		}
		
		int billamount=0;
		List<Room> lr = OYODAO.searchroom(rid); 
		for(Room r : lr) {
	    if(r.getType().equals("Single")) {
	    	billamount = daysbill * 500;
	    }
	    if(r.getType().equals("Double")) {
	    	billamount = daysbill * 800;
		}
		}
	    
		billing.setNoofdays(daysbill);
		billing.setBillamt(billamount);
	     OYODAO.billing(billing);
	     return new ModelAndView("redirect:/");
	 }
	
}
