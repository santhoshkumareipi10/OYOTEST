package com.infinite.java.OYOTask.model;

import java.sql.Date;

public class Booking {

	private String bookid;
	private String roomid;
	private String custname;
	private String city;
	private Date bookdate;
	private Date chkindate;
	private Date chkoutdate;
	
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Date getBookdate() {
		return bookdate;
	}
	public void setBookdate(Date bookdate) {
		this.bookdate = bookdate;
	}
	public Date getChkindate() {
		return chkindate;
	}
	public void setChkindate(Date chkindate) {
		this.chkindate = chkindate;
	}
	public Date getChkoutdate() {
		return chkoutdate;
	}
	public void setChkoutdate(Date chkoutdate) {
		this.chkoutdate = chkoutdate;
	}
	
	
	  
	
}
