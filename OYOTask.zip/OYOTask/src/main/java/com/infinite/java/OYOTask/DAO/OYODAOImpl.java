package com.infinite.java.OYOTask.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.infinite.java.OYOTask.model.Billing;
import com.infinite.java.OYOTask.model.Booking;
import com.infinite.java.OYOTask.model.Room;
import com.infinite.java.OYOTask.model.Status;

public class OYODAOImpl implements OYODAO{

private JdbcTemplate jdbcTemplate;
	
	public OYODAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void booking(Booking booking) {
		String cmd1 = "insert into Booking(BookId, RoomID, CustName, City, BookDate, ChkInDate, ChkOutDate) values(?,?,?,?,?,?,?)";
		 jdbcTemplate.update(cmd1, booking.getBookid(), booking.getRoomid(), booking.getCustname(),booking.getCity(), booking.getBookdate(),booking.getChkindate(),booking.getChkoutdate());	
		 
		 String cmd2= "Update Room Set Status=? where RoomID=?";
		 jdbcTemplate.update(cmd2, "BOOKED",booking.getRoomid());
		
	}

	@Override
	public List<Room> list() {
		
		String sql = "SELECT * FROM Room";
	    List<Room> listroom = jdbcTemplate.query(sql, new RowMapper<Room>() {
	        @Override
	        public Room mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Room room = new Room();
	 
	            room.setRoomid(rs.getString("RoomID"));
	            room.setType(rs.getString("Type"));
	            room.setStatus(Status.valueOf(rs.getString("Status")));
	            room.setCostperday(rs.getInt("CostPerDay"));
	 
	            return room;
	        }
	 
	    });
	    
	    return listroom;
	}
	
	

	@Override
	public void addroom(Room room) {
		String cmd = "insert into Room(Type, CostPerDay) values(?,?)";
		 jdbcTemplate.update(cmd, room.getType(),room.getCostperday());	
		
	}

	@Override
	public List<Booking> blist() {
		String sql = "SELECT * FROM Booking";
	    List<Booking> listbook = jdbcTemplate.query(sql, new RowMapper<Booking>() {
	        @Override
	        public Booking mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Booking book = new Booking();
	            
	            book.setBookid(rs.getString("BookID"));
	            book.setRoomid(rs.getString("RoomID"));
	            book.setCustname(rs.getString("CustName"));
	            book.setCity(rs.getString("City"));
	            book.setBookdate(rs.getDate("BookDate"));
	            book.setChkindate(rs.getDate("ChkInDate"));
	            book.setChkoutdate(rs.getDate("ChkOutDate"));
	            return book;
	        }
	 
	    });
	    
	    return listbook;
	}

	@Override
	public List<Billing> billist() {
		String sql = "SELECT * FROM Billing";
	    List<Billing> listbill = jdbcTemplate.query(sql, new RowMapper<Billing>() {
	        @Override
	        public Billing mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Billing bill = new Billing();
	 
	            bill.setBookid(rs.getString("BookID"));
	            bill.setRoomid(rs.getString("RoomID"));
	            bill.setNoofdays(rs.getInt("NoOfDays"));
	            bill.setBillamt(rs.getInt("BillAmt"));
	 
	            return bill;
	        }
	 
	    });
	    
	    return listbill;
	}

	@Override
	public void billing(Billing billing) {

		String cmd1 = "insert into Billing(BookID, RoomID, NoOfDays, BillAmt) values(?,?,?,?)";
		 jdbcTemplate.update(cmd1, billing.getBookid(), billing.getRoomid(), billing.getNoofdays(), billing.getBillamt());	
		 
		 String cmd2= "Update Room Set Status=? where RoomID=?";
		 jdbcTemplate.update(cmd2, "AVAILABLE",billing.getRoomid());
		
	}

	@Override
	public List<Booking> searchbook(String s) {
		String sql = "SELECT * FROM Booking where RoomID=?";
	    List<Booking> listbook = jdbcTemplate.query(sql,new Object[]{s}, new RowMapper<Booking>() {
	        @Override
	        public Booking mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Booking book = new Booking();
	            
	            book.setRoomid(rs.getString("RoomID"));
	            book.setBookid(rs.getString("BookID"));
	            book.setCustname(rs.getString("CustName"));
	            book.setCity(rs.getString("City"));
	            book.setBookdate(rs.getDate("BookDate"));
	            book.setChkindate(rs.getDate("ChkInDate"));
	            book.setChkoutdate(rs.getDate("ChkOutDate"));
	            return book;
	        }
	 
	    });
	    
	    return listbook;
	}
	

	@Override
	public List<Room> searchroom(String t) {
		String sql = "SELECT * FROM Room where RoomID=?";
	    List<Room> listroom = jdbcTemplate.query(sql,new Object[]{t}, new RowMapper<Room>() {
	        @Override
	        public Room mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Room room = new Room();
	 
	            room.setRoomid(rs.getString("RoomID"));
	            room.setType(rs.getString("Type"));
	            room.setStatus(Status.valueOf(rs.getString("Status")));
	            room.setCostperday(rs.getInt("CostPerDay"));
	 
	            return room;
	        }
	 
	    });
	    
	    return listroom;
	}

	

	
}
