package com.infinite.java.OYOTask.DAO;

import java.util.List;

import com.infinite.java.OYOTask.model.Billing;
import com.infinite.java.OYOTask.model.Booking;
import com.infinite.java.OYOTask.model.Room;

public interface OYODAO {

	void booking(Booking booking);
	void billing(Billing billing);
	List<Room> list();
	List<Booking> blist();
	List<Billing> billist();
	List<Booking> searchbook(String s);
	List<Room> searchroom(String t);
	void addroom(Room room);
}
