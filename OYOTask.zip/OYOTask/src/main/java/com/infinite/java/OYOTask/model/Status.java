package com.infinite.java.OYOTask.model;

public enum Status {
	AVAILABLE, BOOKED

}
